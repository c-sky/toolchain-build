#ifndef _SYS_STAT_H
#define _SYS_STAT_H     1
# include <features.h>
#endif   /* sys/cdefs.h */

