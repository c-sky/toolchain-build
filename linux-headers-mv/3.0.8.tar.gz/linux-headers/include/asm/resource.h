/*
 * arch/csky/include/asm/resource.h
 *
 * This file is subject to the terms and conditions of the GNU General
 * Public License.  See the file COPYING in the main directory of
 * this archive for more details.
 *  
 * (C) Copyright 2009, C-SKY Microsystems Co., Ltd. (www.c-sky.com)
 *  
 */

#ifndef _CSKY_RESOURCE_H
#define _CSKY_RESOURCE_H

#include <asm-generic/resource.h>

#endif /* _CSKY_RESOURCE_H */
