#!/bin/bash
find .  -name "libssp*" -exec rm -rf {} \;
find .  -name "libstdc++.*" -exec rm -rf {} \;
find .  -name "libsupc++.*" -exec rm -rf {} \;
