#!/bin/bash
cd ck801
rm libssp* libstdc++.*
rm libsupc++.*
cd ../
cd ck802
rm libssp* libstdc++.*
rm libsupc++.*
cd ../
cd ck803
rm libssp* libstdc++.*
rm libsupc++.*
cd ../
cd ck807
rm libssp* libstdc++.*
rm libsupc++.*
cd ../
