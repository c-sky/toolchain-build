/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  (C) Copyright 2004, Li Chunqiang (chunqiang_li@c-sky.com)
 *  (C) Copyright 2009, Hu Junshan (junshan_hu@c-sky.com)
 *  (C) Copyright 2009, C-SKY Microsystems Co., Ltd. (www.c-sky.com)
 *  
 */ 

#ifndef _CSKY_SETUP_H
#define _CSKY_SETUP_H

#include <linux/types.h>
#define BOOT_MEM_MAP_MAX        8
#define BOOT_MEM_RAM            1
#define BOOT_MEM_ROM_DATA       2
#define BOOT_MEM_RESERVED       3

#define COMMAND_LINE_SIZE 1024


#endif /* _CSKY_SETUP_H */
