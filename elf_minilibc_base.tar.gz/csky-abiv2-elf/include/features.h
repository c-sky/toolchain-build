/*
 * Copyright (C): 2012 Hangzhou C-SKY Microsystem Co.,LTD.
 * Author: Zhang Zhao  (zhao_zhang@c-sky.com)
 * Contrbutior: Chunqiang Li
 * Date: 2012-5-4
 */


#ifndef _FEATURES_H
#define _FEATURES_H     1

#define __MINILIBC__    1

#endif  /* features.h  */
